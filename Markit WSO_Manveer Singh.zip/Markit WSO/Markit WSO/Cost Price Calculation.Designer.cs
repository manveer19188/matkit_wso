﻿namespace Markit_WSO
{
    partial class Cost_Price_Calculation
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.txt_shares_sold = new System.Windows.Forms.TextBox();
            this.txt_price_per_share = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.btn_calculate = new System.Windows.Forms.Button();
            this.lbl_price_of_sold_shares = new System.Windows.Forms.Label();
            this.lbl_gain_loss_on_sale = new System.Windows.Forms.Label();
            this.lbl_price_of_remaining_shares = new System.Windows.Forms.Label();
            this.lbl_remaining_shares = new System.Windows.Forms.Label();
            this.txt_sell_date = new System.Windows.Forms.TextBox();
            this.errorProvider1 = new System.Windows.Forms.ErrorProvider(this.components);
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider1)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(78, 31);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(64, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Shares Sold";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(61, 65);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(81, 13);
            this.label2.TabIndex = 0;
            this.label2.Text = "Price Per Share";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(92, 97);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(50, 13);
            this.label3.TabIndex = 0;
            this.label3.Text = "Sell Date";
            // 
            // txt_shares_sold
            // 
            this.txt_shares_sold.Location = new System.Drawing.Point(157, 31);
            this.txt_shares_sold.Name = "txt_shares_sold";
            this.txt_shares_sold.Size = new System.Drawing.Size(100, 20);
            this.txt_shares_sold.TabIndex = 1;
            // 
            // txt_price_per_share
            // 
            this.txt_price_per_share.Location = new System.Drawing.Point(157, 65);
            this.txt_price_per_share.Name = "txt_price_per_share";
            this.txt_price_per_share.Size = new System.Drawing.Size(100, 20);
            this.txt_price_per_share.TabIndex = 2;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(47, 204);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(127, 13);
            this.label4.TabIndex = 0;
            this.label4.Text = "Cost Price of Sold Shares";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(79, 226);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(95, 13);
            this.label5.TabIndex = 0;
            this.label5.Text = "Gain Loss On Sale";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(27, 249);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(147, 13);
            this.label6.TabIndex = 0;
            this.label6.Text = "Number Of Remaining Shares";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(16, 272);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(158, 13);
            this.label7.TabIndex = 0;
            this.label7.Text = "Cost Price Of Remaining Shares";
            // 
            // btn_calculate
            // 
            this.btn_calculate.Location = new System.Drawing.Point(157, 135);
            this.btn_calculate.Name = "btn_calculate";
            this.btn_calculate.Size = new System.Drawing.Size(75, 23);
            this.btn_calculate.TabIndex = 4;
            this.btn_calculate.Text = "Calculate";
            this.btn_calculate.UseVisualStyleBackColor = true;
            this.btn_calculate.Click += new System.EventHandler(this.btn_calculate_Click);
            // 
            // lbl_price_of_sold_shares
            // 
            this.lbl_price_of_sold_shares.AutoSize = true;
            this.lbl_price_of_sold_shares.Location = new System.Drawing.Point(199, 204);
            this.lbl_price_of_sold_shares.Name = "lbl_price_of_sold_shares";
            this.lbl_price_of_sold_shares.Size = new System.Drawing.Size(13, 13);
            this.lbl_price_of_sold_shares.TabIndex = 4;
            this.lbl_price_of_sold_shares.Text = "0";
            // 
            // lbl_gain_loss_on_sale
            // 
            this.lbl_gain_loss_on_sale.AutoSize = true;
            this.lbl_gain_loss_on_sale.Location = new System.Drawing.Point(199, 226);
            this.lbl_gain_loss_on_sale.Name = "lbl_gain_loss_on_sale";
            this.lbl_gain_loss_on_sale.Size = new System.Drawing.Size(13, 13);
            this.lbl_gain_loss_on_sale.TabIndex = 5;
            this.lbl_gain_loss_on_sale.Text = "0";
            // 
            // lbl_price_of_remaining_shares
            // 
            this.lbl_price_of_remaining_shares.AutoSize = true;
            this.lbl_price_of_remaining_shares.Location = new System.Drawing.Point(199, 272);
            this.lbl_price_of_remaining_shares.Name = "lbl_price_of_remaining_shares";
            this.lbl_price_of_remaining_shares.Size = new System.Drawing.Size(13, 13);
            this.lbl_price_of_remaining_shares.TabIndex = 6;
            this.lbl_price_of_remaining_shares.Text = "0";
            // 
            // lbl_remaining_shares
            // 
            this.lbl_remaining_shares.AutoSize = true;
            this.lbl_remaining_shares.Location = new System.Drawing.Point(199, 249);
            this.lbl_remaining_shares.Name = "lbl_remaining_shares";
            this.lbl_remaining_shares.Size = new System.Drawing.Size(13, 13);
            this.lbl_remaining_shares.TabIndex = 8;
            this.lbl_remaining_shares.Text = "0";
            // 
            // txt_sell_date
            // 
            this.txt_sell_date.Location = new System.Drawing.Point(157, 94);
            this.txt_sell_date.Name = "txt_sell_date";
            this.txt_sell_date.Size = new System.Drawing.Size(100, 20);
            this.txt_sell_date.TabIndex = 3;
            // 
            // errorProvider1
            // 
            this.errorProvider1.ContainerControl = this;
            // 
            // Cost_Price_Calculation
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(377, 318);
            this.Controls.Add(this.lbl_remaining_shares);
            this.Controls.Add(this.lbl_price_of_remaining_shares);
            this.Controls.Add(this.lbl_gain_loss_on_sale);
            this.Controls.Add(this.lbl_price_of_sold_shares);
            this.Controls.Add(this.btn_calculate);
            this.Controls.Add(this.txt_sell_date);
            this.Controls.Add(this.txt_price_per_share);
            this.Controls.Add(this.txt_shares_sold);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "Cost_Price_Calculation";
            this.Text = "Cost_Price_Calculation";
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txt_shares_sold;
        private System.Windows.Forms.TextBox txt_price_per_share;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Button btn_calculate;
        
        private System.Windows.Forms.Label lbl_price_of_sold_shares;
        private System.Windows.Forms.Label lbl_gain_loss_on_sale;
        private System.Windows.Forms.Label lbl_price_of_remaining_shares;
        private System.Windows.Forms.Label lbl_remaining_shares;
        private System.Windows.Forms.TextBox txt_sell_date;
        private System.Windows.Forms.ErrorProvider errorProvider1;
    }
}