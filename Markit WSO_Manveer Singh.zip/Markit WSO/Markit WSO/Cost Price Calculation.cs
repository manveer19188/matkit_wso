﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Markit_WSO
{
    public partial class Cost_Price_Calculation : Form
    {
        List<Share> shares = null;

        public Cost_Price_Calculation()
        {
            InitializeComponent();
            //Load the collection
            LoadCollection();
        }

        /// <summary>
        /// responsible to load default collection
        /// </summary>
        private void LoadCollection()
        {
            shares = new List<Share>()
            {
                new Share() {Date = Convert.ToDateTime("1/1/2005"),Number = 100,Price = 10 },
                new Share() {Date = Convert.ToDateTime("2/2/2005"),Number = 40, Price = 12 },
                new Share() {Date = Convert.ToDateTime("3/3/2005"),Number = 50, Price = 11 }
            };
        }

        private void btn_calculate_Click(object sender, EventArgs e)
        {
            //validate the number of shares,price and sell date
            if (IsValidForm())
            {
                Share soldShare = new Share()
                {
                    Date = Convert.ToDateTime(txt_sell_date.Text),
                    Number = Convert.ToInt32(txt_shares_sold.Text),
                    Price = Convert.ToDecimal(txt_price_per_share.Text)
                };

                //As per FIFO Price per Share
                int totalShareForSell = soldShare.Number, totalRemainingShare = 0;
                decimal totalCost = 0, totalRemainingCost = 0;

                foreach (var share in shares)
                {
                    //check for sold shares
                    if (totalShareForSell > 0)
                    {
                        if (share.Number < totalShareForSell)
                        {
                            totalCost += share.Cost;
                            totalShareForSell -= share.Number;
                        }
                        else
                        {
                            //for remaining shares
                            totalRemainingCost += share.Price * totalShareForSell;
                            totalRemainingShare += share.Number - totalShareForSell;

                            //for sold shares
                            totalCost += share.Price * totalShareForSell;
                            totalShareForSell -= share.Number;
                        }
                    }
                    else
                    {
                        //for remaining shares
                        totalRemainingShare += share.Number;
                        totalRemainingCost += share.Cost;
                    }
                }

                //1. cost price of sold shares
                lbl_price_of_sold_shares.Text = Math.Round((totalCost / soldShare.Number), 3).ToString();

                //2. Gain loss on Sale
                lbl_gain_loss_on_sale.Text = (soldShare.Cost - totalCost).ToString();

                //3. Number of Remaining Shares
                lbl_remaining_shares.Text = (shares.Sum(s => s.Number) - soldShare.Number).ToString();

                //4. Cost Price of Remaining Shares
                lbl_price_of_remaining_shares.Text = Math.Round((totalRemainingCost / totalRemainingShare), 8).ToString();
            }
        }

        /// <summary>
        /// validate all fields
        /// </summary>
        /// <returns></returns>
        private bool IsValidForm()
        {
            var controls = new[] { txt_sell_date, txt_shares_sold, txt_price_per_share };

            bool isValid = true;
            errorProvider1.Clear();

            foreach (var control in controls.Where(e => String.IsNullOrWhiteSpace(e.Text)))
            {
                errorProvider1.SetError(control, "Please fill the required field");
                isValid = false;
            }

            //if all fields having values then check for valid values
            if (isValid)
            {
                int soldShare = 0;
                Int32.TryParse(txt_shares_sold.Text, out soldShare);
                int maxSoldShare = shares.Sum(s => s.Number);

                decimal soldPrice = 0;
                decimal.TryParse(txt_price_per_share.Text, out soldPrice);

                DateTime sellDate;
                DateTime.TryParse(txt_sell_date.Text, out sellDate);
                DateTime minDate = shares.FirstOrDefault().Date;

                if (soldShare <= 0 || soldShare > maxSoldShare)
                {
                    errorProvider1.SetError(txt_shares_sold, "Please enter valid number.");
                    isValid = false;
                }

                if (soldPrice == 0)
                {
                    errorProvider1.SetError(txt_price_per_share, "Please enter valid price.");
                    isValid = false;
                }

                if (sellDate < minDate)
                {
                    errorProvider1.SetError(txt_sell_date, "Please enter valid date.");
                    isValid = false;
                }
            }
            return isValid;
        }
    }
}
