﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Markit_WSO
{
    public class Share
    {
        /// <summary>
        /// local scope for cost
        /// </summary>
        private decimal _cost;
        /// <summary>
        /// Purchase Date of Share
        /// </summary>
        public DateTime Date { get; set; }
        /// <summary>
        /// Number of Shares
        /// </summary>
        public int Number { get; set; }
        /// <summary>
        /// Price of Share
        /// </summary>
        public decimal Price { get; set; }
        /// <summary>
        /// calculate cost of Share
        /// </summary>
        public decimal Cost
        {
            get
            {
                //get _cost
                _cost = this.Price * this.Number;
                return _cost;
            }
            set
            {
                //set cost value
                _cost = value;
            }
        }
    }

    public enum CostMethod
    {
        FIFO,
        LIFO,
        HighestCost,
        LowestCost,
        WeightedAverage
    }
}
